import asyncio
import pygame as pg

# pathfinder
from pathfinding.core.grid import Grid
from pathfinding.finder.a_star import AStarFinder
from pathfinding.core.diagonal_movement import DiagonalMovement

time = 0
clock = pg.time.Clock()

# score
score = 0
# Setup
x = 1
# num tiles in x
tile_x = 32
# num tiles in y
tile_y = 32
# tile width (x)
tile_width = 25
# tile height
tile_height = 25

watch = 0

pg.init()
screen = pg.display.set_mode((tile_x * tile_width, tile_y * tile_height))
pg.display.set_caption("Game title/Name")
clock = pg.time.Clock()
image = pg.image.load(r"1.png")
white = (255, 255, 255)
black = (0, 0, 0)
green = (0, 255, 0)
blue = (0, 0, 255)
red = (255, 0, 0)
# lists
walls = []
enemy_bullets = []
bullets = []
pixels = []

score_font = pg.font.SysFont(None, 40)


class Button:
    def __init__(self, text, x, y, width, height, action=None):
        self.text = text
        self.rect = pg.Rect(x, y, width, height)
        self.action = action

        # Render the text surface once to optimize performance
        self.text_surf = score_font.render(text, True, (255, 255, 255))
        self.text_rect = self.text_surf.get_rect(center=self.rect.center)

    def draw(self, surface):
        # Get mouse position
        mouse_pos = pg.mouse.get_pos()

        # Change color if mouse hovers over button
        if self.rect.collidepoint(mouse_pos):
            pg.draw.rect(surface, (255, 100, 30), self.rect, border_radius=8)
        else:
            pg.draw.rect(surface, (30, 100, 255), self.rect, border_radius=8)

        # Draw the text on top of the button
        surface.blit(self.text_surf, self.text_rect)

    def check_click(self, mouse_pos):
        # Trigger the assigned function if the button is clicked
        if self.rect.collidepoint(mouse_pos):
            if self.action:
                self.action()


# action of buttons
def start_game():
    # Browser/WASM has no OS process to exec into, so instead of restarting
    # the whole interpreter we just reset all game state in place and drop
    # back into "play" mode. Same effect on screen, works in-browser too.
    reset_game()


def quit_game():
    global running
    running = False


start_button = Button("Start Game", 300, 200, 200, 50, start_game)
quit_button = Button("Quit", 300, 300, 200, 50, quit_game)
buttons = [start_button, quit_button]

# walls
for j in range(0, tile_y):
    for i in range(0, tile_x):
        pixel = image.get_at((i, j))
        pixels.append(pixel)
        if pixel[0] == 0 and pixel[1] == 0 and pixel[2] == 0:

            wall = pg.Rect(i * tile_width, j * tile_height, tile_width, tile_height)
            walls.append(wall)


# Tank
class Tank():

    w = 25
    h = 25

    def __init__(self):
        self.hitbox = pg.Rect(25, 25, self.w, self.h)
        self.speed_x = 0
        self.speed_y = 0

    def update(self):

        keys = pg.key.get_pressed()
        global walls
        for wall in walls:
            if self.hitbox.colliderect(wall) == False:
                if (keys[pg.K_w]) == True and (keys[pg.K_s]) == False and (keys[pg.K_a]) == False and (keys[pg.K_d]) == False:
                    self.speed_x = 0
                    self.speed_y = -2

                if (keys[pg.K_s]) == True and (keys[pg.K_w]) == False and (keys[pg.K_a]) == False and (keys[pg.K_d]) == False:
                    self.speed_x = 0
                    self.speed_y = 2

                if (keys[pg.K_a]) == True and (keys[pg.K_w]) == False and (keys[pg.K_s]) == False and (keys[pg.K_d]) == False:
                    self.speed_x = -2
                    self.speed_y = 0

                if (keys[pg.K_d]) == True and (keys[pg.K_w]) == False and (keys[pg.K_s]) == False and (keys[pg.K_a]) == False:
                    self.speed_x = 2
                    self.speed_y = 0

            if self.hitbox.colliderect(wall) == True:
                if self.speed_x > 0:
                    self.speed_x = 0
                    self.hitbox[0] += -2

                if self.speed_x < 0:
                    self.speed_x = 0
                    self.hitbox[0] += 2

                if self.speed_y > 0:
                    self.speed_y = 0
                    self.hitbox[1] += -2

                if self.speed_y < 0:
                    self.speed_y = 0
                    self.hitbox[1] += 2

        self.hitbox[0] += self.speed_x
        self.hitbox[1] += self.speed_y

    def update_score(self):
        for enemy_bullet in enemy_bullets:
            if enemy_bullet.hitbox.colliderect(self.hitbox):
                self.hitbox = pg.Rect(25, 25, self.w, self.h)
                self.speed_x = 0
                self.speed_y = 0

                enemy_bullets.remove(enemy_bullet)

                global score
                score += -1
                print("score is ", score)

    def draw(self):
        pg.draw.rect(screen, red, self.hitbox)


# attacker
class Pathfinder(Tank):
    def __init__(self, matrix):

        # setup
        self.matrix = matrix
        self.grid = Grid(matrix=matrix)
        # pathfinding
        self.path = []

        # roomba
        self.attacker = pg.sprite.GroupSingle(Attacker(self.empty_path))

        self.range = pg.Rect((self.attacker.sprite.rect.left - 150 / 2), (self.attacker.sprite.rect.top - 150 / 2), 150, 150)

    def empty_path(self):
        self.path = []

    def creat_path(self):
        # start
        start_x, start_y = self.attacker.sprite.get_coord()
        start = self.grid.node(start_x, start_y)

        # end
        end_x = tank.hitbox[0] // 25
        end_y = tank.hitbox[1] // 25
        end = self.grid.node(end_x, end_y)

        # path
        finder = AStarFinder(diagonal_movement=DiagonalMovement.never)
        self.path, _ = finder.find_path(start, end, self.grid)
        self.grid.cleanup()
        self.attacker.sprite.set_path(self.path)

    def update(self):

        # rooomba
        self.attacker.update()
        self.attacker.draw(screen)

        # range
        self.range = pg.Rect((self.attacker.sprite.rect.left - 150 / 2), (self.attacker.sprite.rect.top - 150 / 2), 150, 150)


class Attacker(pg.sprite.Sprite):

    def __init__(self, empty_path):
        super().__init__()
        self.image = pg.image.load('attacker.png').convert_alpha()
        self.rect = self.image.get_rect(center=(775 - 12, 775 - 12))

        self.pos = self.rect.center
        self.speed = 2
        self.direction = pg.math.Vector2(0, 0)

        self.path = []
        self.collision_rects = []
        self.empty_path = empty_path

    def get_coord(self):
        col = self.rect.centerx // 25
        row = self.rect.centery // 25
        return (col, row)

    def set_path(self, path):
        self.path = path
        self.create_collision_rects()
        self.get_direction()

    def create_collision_rects(self):
        if self.path:
            self.collision_rects = []
            for point in self.path:
                x = (point.x * 25) + 12.5
                y = (point.y * 25) + 12.5
                rect = pg.Rect((x - 1, y - 1), (2, 2))
                self.collision_rects.append(rect)

    def get_direction(self):
        if self.collision_rects:
            start = pg.math.Vector2(self.pos)
            end = pg.math.Vector2(self.collision_rects[0].center)
            self.direction = (end - start).normalize()
        else:
            self.direction = pg.math.Vector2(0, 0)
            self.path = []

    def check_collisions(self):
        if self.collision_rects:
            for rect in self.collision_rects:
                if rect.collidepoint(self.pos):
                    del self.collision_rects[0]
                    self.get_direction()
        else:
            self.empty_path()

    def update(self):
        self.pos += self.direction * self.speed
        self.check_collisions()
        self.rect.center = self.pos

        for bullet in bullets:
            if bullet.hitbox.colliderect(self.rect):
                self.rect = self.image.get_rect(center=(775 - 12, 775 - 12))
                self.pos = self.rect.center
                self.speed = 2
                self.direction = pg.math.Vector2(0, 0)

                bullets.remove(bullet)

                global score
                score += 1
                print("score is ", score)


# Bullet
class Bullet(Tank):
    hight = 20
    width = 20

    def __init__(self):
        super().__init__()
        self.hitbox = pg.Rect((tank.hitbox.centerx - self.hight / 2), (tank.hitbox.centery - self.width / 2), self.width, self.hight)
        self.X, self.Y = pg.mouse.get_pos()

        # math
        dx = self.X - tank.hitbox[0]
        dy = self.Y - tank.hitbox[1]
        megV = (dx ** 2 + dy ** 2) ** (1 / 2)
        bullet_speed = 3
        self.speedx = bullet_speed * (dx / megV)
        self.speedy = bullet_speed * (dy / megV)

    def update(self):
        self.hitbox[0] += self.speedx
        self.hitbox[1] += self.speedy

    def draw(self):
        pg.draw.rect(screen, green, self.hitbox)


# enemy Bullet
class Enemy_Bullet(Tank, Attacker):
    hight = 20
    width = 20

    def __init__(self):
        super().__init__()
        self.hitbox = pg.Rect((pathfinder.attacker.sprite.rect.centerx - (self.hight / 2)), (pathfinder.attacker.sprite.rect.centery - (self.width / 2)), self.width, self.hight)
        self.X, self.Y = tank.hitbox.center

        # math
        dx = self.X - pathfinder.attacker.sprite.rect.left
        dy = self.Y - pathfinder.attacker.sprite.rect.top
        megV = (dx ** 2 + dy ** 2) ** (1 / 2)
        bullet_speed = 3
        self.speedx = bullet_speed * (dx / megV)
        self.speedy = bullet_speed * (dy / megV)

    def update(self):
        self.hitbox[0] += self.speedx
        self.hitbox[1] += self.speedy

    def draw(self):
        pg.draw.rect(screen, green, self.hitbox)


# maze
matrix = [

    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0],
    [0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0],
    [0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0],
    [0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0],
    [0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0],
    [0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0],
    [0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0],
    [0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0],
    [0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0],
    [0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0],
    [0, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 1, 1, 1, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]]


pathfinder = Pathfinder(matrix)
tank = Tank()
watch_2 = 0
p = 0
image = pg.transform.scale(image, (800, 800))

mode = "play"   # "play" or "menu" -- replaces the old two-sequential-while-loops structure
running = True

# pg.time.get_ticks() counts up from when the program started, not from when
# the current round started -- it never resets on its own. The desktop version
# got a fresh clock for free every restart because os.execv() launched a whole
# new process. Our in-place reset doesn't, so we track the round's own start
# time and measure elapsed-this-round against that instead of the raw ticks.
round_start_ticks = pg.time.get_ticks()


def reset_game():
    # Re-does everything the old os.execv(...) restart used to accomplish,
    # but in-place (no process restart, since WASM has no OS process to exec into).
    global pathfinder, tank, score, bullets, enemy_bullets, watch, watch_2, p, time, mode, round_start_ticks
    pathfinder = Pathfinder(matrix)
    tank = Tank()
    score = 0
    bullets = []
    enemy_bullets = []
    watch = 0
    watch_2 = 0
    p = 0
    time = 0
    mode = "play"
    round_start_ticks = pg.time.get_ticks()


async def main():
    global time, watch, watch_2, p, mode, running, round_start_ticks

    while running:
        pg.event.pump()

        if mode == "play":
            # update
            # tank
            tank.update()
            tank.update_score()
            # path finding
            if p == 60:
                p = 0
                pathfinder.creat_path()
            if p < 60:
                p += 1

            # draw
            screen.fill((black))
            # map
            screen.blit(image, (0, 0))
            # attacker updat and draw
            pathfinder.update()
            # tank
            tank.draw()
            # draw bullet
            # make

            for event in pg.event.get():
                if event.type == pg.QUIT:
                    running = False
                if watch_2 == 0:
                    if event.type == pg.MOUSEBUTTONDOWN:
                        b = Bullet()
                        bullets.append(b)
                        watch_2 = 17
            if watch_2 > 0:
                watch_2 += -1

            # destroy
            for bullet in bullets:
                breakB = True
                bullet.update()
                bullet.draw()
                for wall in walls:
                    if bullet.hitbox.colliderect(wall):
                        bullets.remove(bullet)
                        breakB = False
                        break
                if breakB == False:
                    break
            # enemy bullet
            if watch < 15:
                watch += 1
            if tank.hitbox.colliderect(pathfinder.range) and watch == 15:
                watch = 0
                eb = Enemy_Bullet()
                enemy_bullets.append(eb)
            for enemy_bullet in enemy_bullets:
                breakA = True
                enemy_bullet.update()
                enemy_bullet.draw()
                for wall in walls:
                    if enemy_bullet.hitbox.colliderect(wall):
                        enemy_bullets.remove(enemy_bullet)
                        breakA = False
                        break
                if breakA == False:
                    break
            # bullet contact
            for enemy_bullet in enemy_bullets:
                breakC = True
                for bullet in bullets:
                    if enemy_bullet.hitbox.colliderect(bullet.hitbox):
                        enemy_bullets.remove(enemy_bullet)
                        bullets.remove(bullet)
                        breakC = False
                        break
                if breakC == False:
                    break
            # draw end
            pg.display.flip()

            # clock -- elapsed time THIS round, not total time since program start
            time = pg.time.get_ticks() - round_start_ticks

            if time > 30000:
                mode = "menu"

        else:  # mode == "menu"
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    running = False
                if event.type == pg.MOUSEBUTTONDOWN:
                    if event.button == 1:
                        for button in buttons:
                            button.check_click(event.pos)

            screen.fill((100, 100, 100))
            score_surface = score_font.render(f"Score: {score}", True, (255, 255, 255))
            screen.blit(score_surface, (20, 20))

            for button in buttons:
                button.draw(screen)

            pg.display.flip()

        clock.tick(30)
        await asyncio.sleep(0)  # required so the browser tab can breathe each frame


asyncio.run(main())
